<?php

namespace App\Controller;

use App\Entity\Municipality;
use App\Entity\Nationality;
use App\Entity\Neighborhood;
use App\Entity\Profession;
use App\Entity\Scholarship;
use App\Entity\SiteClass;
use App\Entity\Variable;
use App\Entity\Vehicle;
use App\Entity\WeaponType;
use App\Entity\Zone;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use App\Entity\LegalCase;
use App\Services\JwtAuth;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;

class CaseController extends AbstractController
{
    public function index()
    {
      $case = $this->getDoctrine()->getRepository(LegalCase::class);
      $cases = $case->findBy(array(
        'state' => 1
      ));

      return $this->json($cases, Response::HTTP_OK, [], [
        ObjectNormalizer::IGNORED_ATTRIBUTES => ['legalCase']
      ]);
    }


  public function all()
  {
    $case = $this->getDoctrine()->getRepository(LegalCase::class);
    $cases = $case->findAll();

    return $this->json($cases, Response::HTTP_OK, [], [
      ObjectNormalizer::IGNORED_ATTRIBUTES => ['legalCase']
    ]);
  }

  public function create(Request $request, JwtAuth $jwt_auth)
  {

    $timezone = new \DateTimeZone('America/Bogota');
    $date = new \DateTime('now', $timezone);
    $json = $request->getContent();
    $json = json_decode($json, true);
    $token = $request->headers->get('authorization');
    $authCheck = $jwt_auth->checkToken($token);

    if ($authCheck) {
      if ($json != null) {

        $victim = $json['victim'];
        $aggressor = $json['aggressor'];
        $direction = $json['direction'];
        $latitude = $json['latitude'];
        $longitude = $json['longitude'];
        $age = $json['age'];
        $civil_status = $json['civil_status'];
        $gender = $json['gender'];
        $font = $json['font'];
        $event_date = $json['date'];
        $time = $json['time'];
        $temporary_behavior = $json['temporary_behavior'];
        $spatial_behavior = $json['spatial_behavior'];
        $vehicle_aggressor_id = $json['vehicle_aggressor_id'];
        $vehicle_victim_id = $json['vehicle_victim_id'];
        $profession_id = $json['profession_id'];
        $municipality_id = $json['municipality_id'];
        $weapon_type_id = $json['weapon_type_id'];
        $site_class_id = $json['site_class_id'];
        $neighborhood_id = $json['neighborhood_id'];
        $scholarship_id = $json['scholarship_id'];
        $nationality_id = $json['nationality_id'];
        $variable_id = $json['variable_id'];
        $zone_id = $json['zone_id'];

        if (!empty($victim) && !empty($vehicle_aggressor_id) &&
            !empty($vehicle_victim_id) && !empty($municipality_id) &&
            !empty($profession_id) && !empty($weapon_type_id) &&
            !empty($aggressor) && !empty($direction) && !empty($latitude) &&
            !empty($longitude) && !empty($age) && !empty($civil_status) &&
            !empty($gender) && !empty($font) && !empty($event_date) &&
            !empty($time) && !empty($temporary_behavior) && !empty($spatial_behavior) &&
            !empty($site_class_id) && !empty($neighborhood_id) && !empty($scholarship_id) &&
            !empty($nationality_id) && !empty($variable_id) && !empty($zone_id)) {

          $doctrine = $this->getDoctrine();
          $db = $doctrine->getManager();

          $vehicle_aggressor_repo = $doctrine->getRepository(Vehicle::class);
          $vehicle_aggressor = $vehicle_aggressor_repo->findOneBy(array(
            'id' => $vehicle_aggressor_id
          ));

          $vehicle_victim_repo = $doctrine->getRepository(Vehicle::class);
          $vehicle_victim = $vehicle_victim_repo->findOneBy(array(
            'id' => $vehicle_victim_id
          ));

          $profession_repo = $doctrine->getRepository(Profession::class);
          $profession = $profession_repo->findOneBy(array(
            'id' => $profession_id
          ));

          $weapon_type_repo = $doctrine->getRepository(WeaponType::class);
          $weapon_type = $weapon_type_repo->findOneBy(array(
            'id' => $weapon_type_id
          ));

          $site_class_repo = $doctrine->getRepository(SiteClass::class);
          $site_class = $site_class_repo->findOneBy(array(
            'id' => $site_class_id
          ));

          $neighborhood_repo = $doctrine->getRepository(Neighborhood::class);
          $neighborhood = $neighborhood_repo->findOneBy(array(
            'id' => $neighborhood_id
          ));

          $scholarship_repo = $doctrine->getRepository(Scholarship::class);
          $scholarship = $scholarship_repo->findOneBy(array(
            'id' => $scholarship_id
          ));

          $nationality_repo = $doctrine->getRepository(Nationality::class);
          $nationality = $nationality_repo->findOneBy(array(
            'id' => $nationality_id
          ));

          $variable_repo = $doctrine->getRepository(Variable::class);
          $variable = $variable_repo->findOneBy(array(
            'id' => $variable_id
          ));

          $zone_repo = $doctrine->getRepository(Zone::class);
          $zone = $zone_repo->findOneBy(array(
            'id' => $zone_id
          ));

          $municipality_repo = $doctrine->getRepository(Municipality::class);
          $municipality = $municipality_repo->findOneBy(array(
            'id' => $municipality_id
          ));

          $case = new LegalCase();
          $case->setVictim($victim);
          $case->setAggressor($aggressor);
          $case->setAge($age);
          $case->setCivilStatus($civil_status);
          $case->setGender($gender);
          $case->setDirection($direction);
          $case->setDate($date);
          $case->setTime(\DateTime::createFromFormat('H:i', $time));
          $case->setLongitude($longitude);
          $case->setLatitude($latitude);
          $case->setFont($font);
          $case->setTemporaryBehavior($temporary_behavior);
          $case->setSpatialBehavior($spatial_behavior);
          $case->setVehicleVictim($vehicle_victim);
          $case->setVehicleAggressor($vehicle_aggressor);
          $case->setProfession($profession);
          $case->setMunicipality($municipality);
          $case->setWeaponType($weapon_type);
          $case->setSiteClass($site_class);
          $case->setNeighborhood($neighborhood);
          $case->setScholarship($scholarship);
          $case->setNationality($nationality);
          $case->setVariable($variable);
          $case->setZone($zone);
          $case->setCreatedAt($date);
          $case->setUpdatedAt($date);

          $db->persist($case);
          $db->flush();

          $cases = $case->findAll();
          $status = 'success';
          $code = 200;
          $mensaje = 'El caso se ha creado correctamente.';

          $data = [
            'status' => $status,
            'code' => $code,
            'message' => $mensaje,
            'data' => $cases
          ];

          return $this->json($data);
        } else {

          $status = 'error';
          $code = 200;
          $mensaje = 'El caso no se ha creado.';
        }
      } else {

        $status = 'error';
        $code = 200;
        $mensaje = 'El caso no se ha creado.';
      }
    }else{
      $status = 'error';
      $code = 400;
      $mensaje = 'No tiene permisos para realizar esa operación.';
    }

    $data = [
      'status' => $status,
      'code' => $code,
      'message' => $mensaje,
    ];

    return $this->json($data);
  }

  public function update(Request $request, JwtAuth $jwt_auth)
  {
    $timezone = new \DateTimeZone('America/Bogota');
    $date = new \DateTime('now', $timezone);
    $json = $request->getContent();
    $json = json_decode($json, true);
    $token = $request->headers->get('authorization');
    $authCheck = $jwt_auth->checkToken($token);
    if ($authCheck){
      if($json != null){

        $victim = $json['victim'];
        $aggressor = $json['aggressor'];
        $direction = $json['direction'];
        $latitude = $json['latitude'];
        $longitude = $json['longitude'];
        $age = $json['age'];
        $civil_status = $json['civil_status'];
        $gender = $json['gender'];
        $font = $json['font'];
        $event_date = $json['date'];
        $time = $json['time'];
        $temporary_behavior = $json['temporary_behavior'];
        $spatial_behavior = $json['spatial_behavior'];
        $vehicle_aggressor_id = $json['vehicle_aggressor_id'];
        $vehicle_victim_id = $json['vehicle_victim_id'];
        $profession_id = $json['profession_id'];
        $municipality_id = $json['municipality_id'];
        $weapon_type_id = $json['weapon_type_id'];
        $site_class_id = $json['site_class_id'];
        $neighborhood_id = $json['neighborhood_id'];
        $scholarship_id = $json['scholarship_id'];
        $nationality_id = $json['nationality_id'];
        $variable_id = $json['variable_id'];
        $zone_id = $json['zone_id'];
        $case_id = $json['case_id'];

        if (!empty($victim) && !empty($vehicle_aggressor_id) &&
          !empty($vehicle_victim_id) && !empty($municipality_id) &&
          !empty($profession_id) && !empty($weapon_type_id) &&
          !empty($aggressor) && !empty($direction) && !empty($latitude) &&
          !empty($longitude) && !empty($age) && !empty($civil_status) &&
          !empty($gender) && !empty($font) && !empty($event_date) &&
          !empty($time) && !empty($temporary_behavior) && !empty($spatial_behavior) &&
          !empty($site_class_id) && !empty($neighborhood_id) && !empty($scholarship_id) &&
          !empty($nationality_id) && !empty($variable_id) && !empty($zone_id)) {

          $doctrine = $this->getDoctrine();
          $db = $doctrine->getManager();
          $case_repo = $doctrine->getRepository(LegalCase::class);
          $case = $case_repo->findOneBy(array(
            'id' => $case_id,
          ));

          $vehicle_aggressor_repo = $doctrine->getRepository(Vehicle::class);
          $vehicle_aggressor = $vehicle_aggressor_repo->findOneBy(array(
            'id' => $vehicle_aggressor_id
          ));

          $vehicle_victim_repo = $doctrine->getRepository(Vehicle::class);
          $vehicle_victim = $vehicle_victim_repo->findOneBy(array(
            'id' => $vehicle_victim_id
          ));

          $profession_repo = $doctrine->getRepository(Profession::class);
          $profession = $profession_repo->findOneBy(array(
            'id' => $profession_id
          ));

          $weapon_type_repo = $doctrine->getRepository(WeaponType::class);
          $weapon_type = $weapon_type_repo->findOneBy(array(
            'id' => $weapon_type_id
          ));

          $site_class_repo = $doctrine->getRepository(SiteClass::class);
          $site_class = $site_class_repo->findOneBy(array(
            'id' => $site_class_id
          ));

          $neighborhood_repo = $doctrine->getRepository(Neighborhood::class);
          $neighborhood = $neighborhood_repo->findOneBy(array(
            'id' => $neighborhood_id
          ));

          $scholarship_repo = $doctrine->getRepository(Scholarship::class);
          $scholarship = $scholarship_repo->findOneBy(array(
            'id' => $scholarship_id
          ));

          $nationality_repo = $doctrine->getRepository(Nationality::class);
          $nationality = $nationality_repo->findOneBy(array(
            'id' => $nationality_id
          ));

          $variable_repo = $doctrine->getRepository(Variable::class);
          $variable = $variable_repo->findOneBy(array(
            'id' => $variable_id
          ));

          $zone_repo = $doctrine->getRepository(Zone::class);
          $zone = $zone_repo->findOneBy(array(
            'id' => $zone_id
          ));

          $municipality_repo = $doctrine->getRepository(Municipality::class);
          $municipality = $municipality_repo->findOneBy(array(
            'id' => $municipality_id
          ));

            $case->setVictim($victim);
            $case->setAggressor($aggressor);
            $case->setAge($age);
            $case->setCivilStatus($civil_status);
            $case->setGender($gender);
            $case->setDirection($direction);
            $case->setDate($date);
            $case->setTime(\DateTime::createFromFormat('H:i', $time));
            $case->setLongitude($longitude);
            $case->setLatitude($latitude);
            $case->setFont($font);
            $case->setTemporaryBehavior($temporary_behavior);
            $case->setSpatialBehavior($spatial_behavior);
            $case->setVehicleVictim($vehicle_victim);
            $case->setVehicleAggressor($vehicle_aggressor);
            $case->setProfession($profession);
            $case->setMunicipality($municipality);
            $case->setWeaponType($weapon_type);
            $case->setSiteClass($site_class);
            $case->setNeighborhood($neighborhood);
            $case->setScholarship($scholarship);
            $case->setNationality($nationality);
            $case->setVariable($variable);
            $case->setZone($zone);
            $case->setUpdatedAt($date);

            $db->persist($case);
            $db->flush();

            $cases = $case->findAll();
            $status = 'success';
            $code = 200;
            $mensaje = 'Datos modificados correctamente.';

          $data = [
            'status' => $status,
            'code' => $code,
            'message' => $mensaje,
            'data' => $cases
          ];

          return $this->json($data);
        }else{
          $status = 'error';
          $code = 200;
          $mensaje = 'Todos los campos son obligatorios.';
        }
      }else{
        $status = 'error';
        $code = 200;
        $mensaje = 'No se han modificados los datos, intentelo nuevamente.';
      }
    }else{
      $status = 'error';
      $code = 400;
      $mensaje = 'No tiene permisos para realizar esa operación.';
    }

    $data = [
      'status' => $status,
      'code' => $code,
      'message' => $mensaje,
    ];

    return $this->json($data);
  }

  public function delete(Request $request, JwtAuth $jwt_auth)
  {
    $timezone = new \DateTimeZone('America/Bogota');
    $date = new \DateTime('now', $timezone);
    $json = $request->getContent();
    $json = json_decode($json, true);
    $token = $request->headers->get('authorization');
    $authCheck = $jwt_auth->checkToken($token);
    if ($authCheck) {
      if($json != null){

        $case_id = $json['case_id'];

        if (!empty($case_id)) {

          $doctrine = $this->getDoctrine();
          $db = $doctrine->getManager();
          $case_repo = $doctrine->getRepository(LegalCase::class);
          $case = $case_repo->findOneBy(array(
            'id' => $case_id,
          ));

          $case->setState(0);
          $case->setUpdatedAt($date);

          $db->persist($case);
          $db->flush();

          $cases = $case->findAll();
          $status = 'success';
          $code = 200;
          $mensaje = 'Datos deshabilitados correctamente.';

          $data = [
            'status' => $status,
            'code' => $code,
            'message' => $mensaje,
            'data' => $cases
          ];

          return $this->json($data);
        }else{
          $status = 'error';
          $code = 200;
          $mensaje = 'Todos los campos son obligatorios.';
        }
      }else{
        $status = 'error';
        $code = 200;
        $mensaje = 'No se han modificados los datos, intentelo nuevamente.';
      }
    }else{
      $status = 'error';
      $code = 400;
      $mensaje = 'No tiene permisos para realizar esa operación.';
    }

    $data = [
      'status' => $status,
      'code' => $code,
      'message' => $mensaje,
    ];

    return $this->json($data);
  }

  public function restore(Request $request, JwtAuth $jwt_auth)
  {
    $timezone = new \DateTimeZone('America/Bogota');
    $date = new \DateTime('now', $timezone);
    $json = $request->getContent();
    $json = json_decode($json, true);
    $token = $request->headers->get('authorization');
    $authCheck = $jwt_auth->checkToken($token);
    if ($authCheck) {
      if($json != null){

        $case_id = $json['case_id'];

        if (!empty($case_id)) {

          $doctrine = $this->getDoctrine();
          $db = $doctrine->getManager();
          $case_repo = $doctrine->getRepository(LegalCase::class);
          $case = $case_repo->findOneBy(array(
            'id' => $case_id,
          ));

          $case->setState(1);
          $case->setUpdatedAt($date);

          $db->persist($case);
          $db->flush();

          $cases = $case->findAll();
          $status = 'success';
          $code = 200;
          $mensaje = 'Datos habilitados correctamente.';

          $data = [
            'status' => $status,
            'code' => $code,
            'message' => $mensaje,
            'data' => $cases
          ];

          return $this->json($data);
        }else{
          $status = 'error';
          $code = 200;
          $mensaje = 'Todos los campos son obligatorios.';
        }
      }else{
        $status = 'error';
        $code = 200;
        $mensaje = 'No se han modificados los datos, intentelo nuevamente.';
      }
    }else{
      $status = 'error';
      $code = 400;
      $mensaje = 'No tiene permisos para realizar esa operación.';
    }

    $data = [
      'status' => $status,
      'code' => $code,
      'message' => $mensaje,
    ];

    return $this->json($data);
  }

  public function theftAnalysi(Request $request){
    $json = $request->getContent();
    $json = json_decode($json, true);

    if($json != null){

      $variable = (!empty($json['variable'])) ? $json['variable'] : null;
      $table = (!empty($json['table'])) ? $json['table'] : null;
      $column = (!empty($json['column'])) ? $json['column'] : null;

      $doctrine = $this->getDoctrine();
      $db = $doctrine->getConnection();

      if (!empty($variable) && !empty($table) && empty($column)) {

        $query = "SELECT p.name, count(lc.id) AS quantity FROM $table p
                  INNER JOIN legal_case lc
                  ON p.id = lc.profession_id
                  WHERE lc.variable_id = $variable
                  GROUP BY p.id;";

        $stmt = $db->prepare($query);
        $params = array();
        $stmt->execute($params);
        $result = $stmt->fetchAll();

        $count = count($result);
        if ($count > 0) {

          return $this->json($result);
        } else {

          $status = 'success';
          $code = 200;
          $mensaje = 'No se han encontrado datos para su consulta.';
        }
      }elseif (!empty($variable) && !empty($column) && empty($table)){

        $query = "SELECT lc.$column, count(lc.id) AS quantity FROM legal_case lc
                  WHERE lc.variable_id = $variable
                  GROUP BY lc.$column;";

        $stmt = $db->prepare($query);
        $params = array();
        $stmt->execute($params);
        $result = $stmt->fetchAll();

        $count = count($result);
        if ($count > 0) {

          return $this->json($result);
        } else {

          $status = 'success';
          $code = 200;
          $mensaje = 'No se han encontrado datos para su consulta.';
        }
      }elseif(!empty($variable) && empty($column) && empty($table)){

        $query = "SELECT
                  CASE WHEN (age < 18) THEN 'Menores de 18 años' ELSE
                    CASE WHEN (age BETWEEN 18 AND 30) THEN 'De 18 a 30 años' ELSE
                      CASE WHEN (age BETWEEN 30 AND 45) THEN 'De 30 a 45 años' ELSE
                        CASE WHEN (age >= 45) THEN 'De 45 años o más'
                        END
                      END
                    END
                  END age_range,
                  count(id) AS quantity,
                  (SELECT COUNT(legal_case.id)*100/COUNT(lc.id)
                  FROM legal_case lc
                  ) AS percentage
                  FROM legal_case
                  WHERE variable_id = $variable
                  GROUP BY age_range DESC;";

        $stmt = $db->prepare($query);
        $params = array();
        $stmt->execute($params);
        $result = $stmt->fetchAll();

        $count = count($result);
        if ($count > 0) {

          return $this->json($result);
        } else {

          $status = 'success';
          $code = 200;
          $mensaje = 'No se han encontrado datos para su consulta.';
        }
      }else{
        $status = 'error';
        $code = 200;
        $mensaje = 'No se han encontrado datos para su consulta.';
      }

      $data = [
        'status' => $status,
        'code' => $code,
        'message' => $mensaje,
      ];

      return $this->json($data);
    }
  }

  public function query(Request $request, JwtAuth $jwt_auth)
  {
    $timezone = new \DateTimeZone('America/Bogota');
    $date = new \DateTime('now', $timezone);
    $json = $request->getContent();
    $json = json_decode($json, true);
    $token = $request->headers->get('authorization');
    $authCheck = $jwt_auth->checkToken($token);
    if ($authCheck) {
      if($json != null){

        $case_id = $json['case_id'];

        if (!empty($case_id)) {

          $doctrine = $this->getDoctrine();
          $case_repo = $doctrine->getRepository(LegalCase::class);
          $case = $case_repo->findOneBy(array(
            'id' => $case_id,
          ));

          $status = 'success';
          $code = 200;
          $mensaje = 'Datos habilitados correctamente.';

          $data = [
            'status' => $status,
            'code' => $code,
            'message' => $mensaje,
            'data' => $case
          ];

          return $this->json($data);
        }else{
          $status = 'error';
          $code = 200;
          $mensaje = 'Todos los campos son obligatorios.';
        }
      }else{
        $status = 'error';
        $code = 200;
        $mensaje = 'No se han modificados los datos, intentelo nuevamente.';
      }
    }else{
      $status = 'error';
      $code = 400;
      $mensaje = 'No tiene permisos para realizar esa operación.';
    }

    $data = [
      'status' => $status,
      'code' => $code,
      'message' => $mensaje,
    ];

    return $this->json($data);
  }
}
